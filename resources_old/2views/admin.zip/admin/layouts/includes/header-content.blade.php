<section class="content-header">
	<h1>{{ ucfirst( $path_name ) }}</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
		<li><a href="#">{{ $path_name }}</a></li>      
	</ol>
</section>