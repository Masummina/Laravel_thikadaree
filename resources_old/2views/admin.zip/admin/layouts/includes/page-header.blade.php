<div class="box-header">
	<h3 class="box-title"> <b>{{ ucfirst(str_singular($path_name)) }} List </b></h3> 
	{{-- <button  type="button" class="btn btn-primary" data-toggle="modal" data-target="#{{$path_name}}Modal" data-whatever="@mdo">Add New</button>
	<span class="message-area"></span> --}}
</div>