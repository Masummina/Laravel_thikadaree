<header class="main-header">

      <!-- Logo -->

      <a href="{!! url('/dashboard') !!}" class="logo">

        <!-- mini logo for sidebar mini 50x50 pixels -->

        <span class="logo-mini"><b>CRM</b> Panel </span>

        <!-- logo for regular state and mobile devices -->

        <span class="logo-lg"><img src="{{ asset('images/logo.png') }}" height="30" alt="logo"></span>

      </a>       

</header>